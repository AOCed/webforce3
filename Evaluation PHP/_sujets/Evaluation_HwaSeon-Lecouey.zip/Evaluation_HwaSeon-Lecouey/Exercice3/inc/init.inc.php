<?php 

// Page d'initialisation 
	session_start();
	require_once('connection.inc.php');

?>