<?php

$sql = 'SELECT * FROM articles LEFT JOIN users ON users.id WHERE articles.id = 10';
