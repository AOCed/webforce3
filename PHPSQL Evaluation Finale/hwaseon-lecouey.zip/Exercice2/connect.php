<?php

$db = new PDO('mysql:host=localhost;dbname=exo1_userslist;charset=utf8', 'root', '');