<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Faisons le ménage!</title>
</head>
<body>
	<form action="" method="post">

		<label for="">Marque</label>
		<input type="text" name="brand" id="brand" />

		<label for="">Modèle</label>
		<input type="text" name="model" id="model" />

		<label for="">Année</label>
		<input type="number" name="year" id="year"/>
		
		<label for="">Couleur</label>
		<input type="text" name="color" id="color"/>

		<input type="submit" id="submit" value="envoyer">
	</form>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script>
	$(document).ready(function(){
		$(#submit).click(function{
			$.ajax({
				url : 'exo3ajax.php',
				type : 'post',
				data :
				
				function(data){
					if(data == 'success') {
						$("#resultat").html('<p>Vos données ont bien été enregistrées.</p>');
					} else {
						 $("#resultat").html("<p>Erreur lors de l'enregistrement...</p>");
					}

				},
				'text'
			});
		})
	})

</script>
</html>

<?php 

if(!empty($_POST))
?>