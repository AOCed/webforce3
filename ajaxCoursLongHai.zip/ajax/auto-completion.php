<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>auto-completion</title>
    </head>
    <body>
        <header>
            <h1>auto-completion</h1>
        </header>
        <section>
            <h2>formulaire de destination</h2>
            <form><!-- A COMPLETER -->
                <input type="text" name="destination" required autocomplete="off" />
                <div class="choix">
                    <!-- ICI ON VERRA LES CHOIX POSSIBLES-->
                </div>
            </form>
        </section>
        
        <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
  
      <script type="text/javascript">
// ON VEUT AJOUTER NOTRE CODE AVEC jQuery
$(function(){
    // MON CODE SERA ACTIVE QUAND LA PAGE SERA PRETE
    
    // AJOUTER UN LISTENER SUR LE CHAMP input[name=destination]
    $("input[name=destination]").on("keyup", function(){
        // CE CODE SERA ACTIVE QUAND L'UTILISATEUR VA TAPER DANS LE CHAMP input
        var textEntre = $("input[name=destination]").val();
        // TEST
        console.log(textEntre);
        // JE VEUX ENVOYER CE TEXTE AU SERVEUR AVEC AJAX
        // ET LE SERVEUR VA ME RENVOYER UNE LISTE DE NOMS QUI VA CORRESPONDRE
        // http://api.jquery.com/load/
        // ON PASSE LES PARAMETRES POST EN 2e PARAMETRE AVEC UN OBJET JS
        $(".choix").load("libs/services.php", { action : "getDestinations", destination : textEntre });
        
        // MONTRER LES CHOIX
        $(".choix").show();

    });
    
    // AJOUTER UN LISTENER SUR LA BALISE .ville
    // MAIS ATTENTION, CES BALISES N'EXISTENT PAS AU CHARGEMENT DE LA PAGE
    // ASTUCE POUR CONTOURNER LE PROBLEME
    // ON AJOUTE LE LISTENER SUR UN CONTAINER QUI EXISTE AU CHARGEMENT DE LA PAGE
    // ET ON AJOUTE UN PARAMETRE QUI PRECISE QUE LA CIBLE DU click EST UNE BALISE .ville
    $(".choix").on("click", ".ville", function(){
        // COPIER LE CONTENU DE LA VILLE DANS LE CHAMP INPUT
        var ville = $(this).html();
        $("input[name=destination]").val(ville);
        
        // CACHER LA LISTE DES CHOIX
        $(".choix").slideUp();
    });
});
      </script>
  
    </body>
</html>