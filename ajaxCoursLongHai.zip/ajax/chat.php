<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>CHAT</title>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	</head>
	<body>
		<header>
			<h1>CHAT</h1>
		</header>
		<main>
<section>
	<h2>FORMULAIRE DE CHAT</h2>
	<form class="chat ajax" action="libs/services.php" method="POST">
		<input type="text" placeholder="PSEUDO" name="pseudo" required />
		<input type="text" placeholder="ENTREZ VOTRE MESSAGE" name="message" required />
		<input type="submit" value="ENVOYER" />
		<input type="hidden" name="action" value="addChat" />
		<div class="retour">
		<!--ICI ON VERRA LE MESSAGE DE RETOUR-->
<?php

// ICI JE VEUX AFFICHER LES MESSAGES DE TOUS LES UTILISATEURS
// IL FAUT QUE JE ME CONNECTE A LA BASE DE DONNEES
require_once("inc/connexion.inc.php");
// CHARGER MES FONCTIONS
require_once("inc/functions.inc.php");
// UTILISER MES FONCTIONS
// LIRE ET AFFICHER LES LIGNES DE LA TABLE chat
getChats();

?>
		</div>
	</form>
</section>		
	

		</main>
		<footer>
			<p>tous droits réservés 2017</p>
		</footer>

<script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
  
<script type="text/javascript" src="assets/js/ajaxForm.js">
</script>

<script type="text/javascript">
// METTRE A JOUR LA DISCUSSION TOUTES LES SECONDES
// https://developer.mozilla.org/fr/docs/Web/API/WindowTimers/setInterval
setInterval(function()
{ 
	// RELANCER UNE REQUETE AJAX POUR METTRE A JOUR LA BALISE .retour
	$(".retour").load("libs/services.php?action=getChats");
}, 1000);

// BASE DE CODE POUR UTILISER jQuery
$(function(){

	// ON VEUT EFFACER LE CONTENU DU input[name=message]
	// UNE FOIS QUE LE MESSAGE A ETE ENVOYE
	$("form.chat").on("submit", function(){
		// ON VEUT EFFACER LE CONTENU DE input[name=message]
		$("form.chat input[name=message]")	// SELECTIONNE LA BALISE SUR LAQUELLE JE VEUX AGIR
				.val("")					// VIDE LE CHAMP INPUT
				.focus();					// REMET LE FOCUS
	});
});

// CORS
// https://openclassrooms.com/courses/ajax-et-l-echange-de-donnees-en-javascript/l-xmlhttprequest-cross-domain
// https://developer.mozilla.org/fr/docs/HTTP/Access_control_CORS
</script>
	</body>
</html>