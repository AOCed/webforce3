<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>scrolling infini</title>
        <link rel="stylesheet" href="assets/css/style.css" type="text/css" />
    </head>
    <body>
        <header>
            <h1>scrolling infini</h1>
        </header>
        <section>
            <h2>section 1</h2>
            <p>
                Lorem ipsum dolor sit amet, consectetuer adipiscing elit,
                sed diam nonummy nibh euismod tincidunt ut laoreet dolore
                magna aliquam erat volutpat. Ut wisi enim ad minim veniam,
                quis nostrud exerci tation ullamcorper suscipit lobortis nisl
                ut aliquip ex ea commodo consequat. Duis autem vel eum iriure
                dolor in hendrerit in vulputate velit esse molestie consequat,
                vel illum dolore eu feugiat nulla facilisis at vero eros et
                accumsan et iusto odio dignissim qui blandit praesent luptatum
                zzril delenit augue duis dolore te feugait nulla facilisi.
                Nam liber tempor cum soluta nobis eleifend option congue
                nihil imperdiet doming id quod mazim placerat facer possim
                assum. Typi non habent claritatem insitam; est usus legentis
                in iis qui facit eorum claritatem. Investigationes
                demonstraverunt lectores legere me lius quod ii legunt saepius.
                Claritas est etiam processus dynamicus, qui sequitur mutationem
                consuetudium lectorum. Mirum est notare quam littera gothica,
                quam nunc putamus parum claram, anteposuerit litterarum formas
                humanitatis per seacula quarta decima et quinta decima. Eodem
                modo typi, qui nunc nobis videntur parum clari, fiant sollemnes
                in futurum.
            </p>
        </section>
        <footer>
            <div class="bouton3">cliquer ici pour charger plus de contenu</div>
        </footer>
        <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
  
      <script type="text/javascript">
var compteurAjax = 0;       // MEMORISER LE NOMBRE DE REQUETES AJAX

var idSection = 1;  // MEMORISER L'ID DE LA SECTION A CHARGER

var testAjaxEnCours = false;

var chargerSection = function()
{
    // ON ATTEND LA FIN DU CHARGEMENT
    if (testAjaxEnCours)
    {
        return;
    }
    // VERIFIER SI LE COMPTEUR N'A PAS DEPASSE UN SEUIL MAXIMUM
    if (compteurAjax > 10) 
    {
        return;
    }
    
    // ON AJOUTE UN AU COMPTEUR
    compteurAjax = compteurAjax+1;
    
    testAjaxEnCours = true;
    // ce code sera activé quand on va cliquer sur .bouton3

    // AVEC AJAX, ON VA CHARGER TOUTE LA SECTION
    // ET IL FAUT AJOUTER LA SECTION AVANT LA BALISE footer
    // http://api.jquery.com/jQuery.post/
    $.post( "libs/services.php", 
            { action: "getSection", idSection: idSection },
            function(data) {
                // data CONTIENDRA LA REPONSE DU SERVEUR
                // CE CODE SERA ACTIVE QUAND LA REPONSE DU SERVEUR SERA RECUE
                // MAINTENANT, IL FAUT INSERER LA REPONSE DANS LA PAGE 
                // AVANT LA BALISE footer
                $("footer").before(data);
                
                // autoriser une nouvelle requete Ajax
                testAjaxEnCours = false;
            });
    
    // AJOUTER UN A LA VARIABLE idSection
    idSection = idSection + 1;
};

var chargerSectionBouton = function ()
{
    // REMETTRE LE COMPTEUR A ZERO
    compteurAjax = 0;
    
    // RELANCE LE CHARGEMENT AJAX
    chargerSection();
}

// ON VEUT AJOUTER NOTRE CODE AVEC jQuery
$(function(){
    // MON CODE SERA ACTIVE QUAND LA PAGE SERA PRETE
    
    // QUAND ON CLIQUE OU QUAND ON PASSE LA SOURIS SUR .bouton3
    // ALORS ON VA CHARGER DU CONTENU SUPPLEMENTAIRE
    $(".bouton3").on("click mouseover", chargerSectionBouton);

    // IL FAUT QUE JE SUIVE LE SCROLL DE LA FENETRE 
    // POUR SAVOIR SI ON EST EN BAS DE LA PAGE
    // ON AJOUTE UN LISTENER SUR LE scroll DE LA FENETRE
    $(window).on("scroll", function(){
        // POSITION EN PIXELS DU SCROLL
        var positionScroll  = $(window).scrollTop();
        // http://api.jquery.com/outerheight/
        var hauteurPage     = $(document).outerHeight();
        var hauteurFenetre  = $(window).outerHeight();
        
        var pourcentageScroll = Math.round(100 * positionScroll / (hauteurPage - hauteurFenetre));
        
        // TEST
        // console.log(pourcentageScroll);
        
        // SI LE POURCENTAGE DE SCROLL EST SUPERIEUR A 90%
        if (pourcentageScroll > 90)
        {
            // ALORS ON DECLENCHE LE CHARGEMENT DE CONTENU PAR AJAX
            chargerSection();
        }
    });

});
      </script>
  
    </body>
</html>