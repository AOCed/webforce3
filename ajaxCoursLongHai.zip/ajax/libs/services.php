<?php
// AJAX
// Asynchronous
// Javascript
// And
// XML

//var_dump($_POST);
//var_dump($_REQUEST);		// VA INCLURE $_GET ET $_POST

// JE VEUX ENREGISTRER L'EMAIL DANS UNE TABLE newsletter DANS UNE BDD ajax
// CODE POUR SE CONNECTER A LA BDD
require_once("../inc/connexion.inc.php");
// ON CHARGE TOUTES LES FONCTIONS
require_once("../inc/functions.inc.php");


switch($_REQUEST["action"])
{
	case "addNewsletter":
		addNewsletter();
		break;
	case "addChat":
		addChat();
		break;
	case "getChats":
		getChats();
		break;
	case "getDestinations":
		getDestinations();
		break;
	case "getSection":
		getSection();
		break;
	default:
		echo "SERVICE NON DEFINI";
		break;
}

function addChat()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;
	// RECUPERER LES INFOS DU FORMULAIRE
	$pseudo 	= $_REQUEST["pseudo"];
	$message 	= $_REQUEST["message"];
	// COMPLETER LES INFOS
	$date		= date("Y-m-d H:i:s");

	// VERIFICATION DE SECURITE
	if (!empty($pseudo) && !empty($message))
	{
		// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
		$data = 
			[ 
				"pseudo" 	=> $pseudo,  
				"message" 	=> $message,  
				"date" 		=> $date,  
			];

		// REQUETE SQL POUR AJOUTER UNE LIGNE
		$sql = "INSERT INTO chat ( ch_pseudo, ch_message, ch_date ) VALUES ( :pseudo, :message, :date );";

		// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
		$req = $connexion->prepare($sql);
		// EXECUTER LA REQUETE
		$req->execute($data);

		// MESSAGE DE RETOUR
		// echo "$pseudo a écrit: $message";
	}

	// ON AFFICHE TOUS LES MESSAGES
	getChats();
}

function addNewsletter()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;
	// RECUPERER LES INFOS DU FORMULAIRE
	$email = $_REQUEST["email"];

	// VERIFICATION DE SECURITE
	if (!empty($email) && (filter_var($email, FILTER_VALIDATE_EMAIL) !== false) )
	{
		// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
		$data = [ "email" => $email ];

		// REQUETE SQL POUR AJOUTER UNE LIGNE
		$sql = "INSERT INTO newsletter ( ne_email ) VALUES ( :email );";

		// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
		$req = $connexion->prepare($sql);
		// EXECUTER LA REQUETE
		$req->execute($data);

		// MESSAGE DE RETOUR
		echo "MERCI DE VOTRE INSCRIPTION AVEC $email";
	}
}