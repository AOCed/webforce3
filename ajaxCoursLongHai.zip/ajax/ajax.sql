-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Ven 06 Janvier 2017 à 09:23
-- Version du serveur :  10.1.8-MariaDB
-- Version de PHP :  5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ajax`
--

-- --------------------------------------------------------

--
-- Structure de la table `chat`
--

CREATE TABLE `chat` (
  `ch_id` int(11) NOT NULL,
  `ch_pseudo` varchar(255) NOT NULL,
  `ch_message` varchar(1000) NOT NULL,
  `ch_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `chat`
--

INSERT INTO `chat` (`ch_id`, `ch_pseudo`, `ch_message`, `ch_date`) VALUES
(1, 'test', 'message1431', '2017-01-05 14:31:37'),
(2, 'user1', 'message user1', '2017-01-05 14:54:07'),
(3, 'user2', 'message user2', '2017-01-05 14:54:23'),
(4, 'user1', 'test 1519', '2017-01-05 15:20:03'),
(5, 'user1', 'test1523', '2017-01-05 15:23:07'),
(6, 'user1', 'test1523', '2017-01-05 15:23:52'),
(7, 'user2', 'coucou', '2017-01-05 15:24:08'),
(8, 'user2', 'tu me reponds?', '2017-01-05 15:27:40'),
(9, 'user1', 'oui, oui, c''est la pause', '2017-01-05 15:34:51'),
(10, 'user2', 'ALLEZ LA PAUSE', '2017-01-05 15:35:10'),
(11, 'user1', 'alors ? ca marche', '2017-01-05 15:35:43'),
(12, 'user2', 'OUI CA MARCHE', '2017-01-05 15:35:52'),
(13, 'user2', 'jfhf', '2017-01-05 16:02:18'),
(14, 'user1', 'test 1617', '2017-01-05 16:17:40'),
(15, 'user1', 'test1618', '2017-01-05 16:18:59'),
(16, 'user1', 'test1618 bis', '2017-01-05 16:19:14'),
(17, 'user1', 'sddhskdfj', '2017-01-05 16:19:22'),
(18, 'user1', 'test1624', '2017-01-05 16:24:51'),
(19, 'user1', 'fkgjjgqs', '2017-01-05 16:26:15'),
(20, 'user1', 'ksdjfghjksdf', '2017-01-05 16:26:16'),
(21, 'user1', 'sdfdgjqsdfj', '2017-01-05 16:26:17'),
(22, 'user1', 'sdfjklsdhfkjsd', '2017-01-05 16:26:17'),
(23, 'user1', 'sdfhnszeazdazez', '2017-01-05 16:28:52');

-- --------------------------------------------------------

--
-- Structure de la table `newsletter`
--

CREATE TABLE `newsletter` (
  `ne_id` int(11) NOT NULL,
  `ne_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `newsletter`
--

INSERT INTO `newsletter` (`ne_id`, `ne_email`) VALUES
(1, 'test@mail.me'),
(2, 'test1245@mail.me'),
(3, 'test1355@mail.me'),
(4, 'test1405@mail.me'),
(5, 'test1410@mail.me'),
(6, 'test1413@mail.me');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`ch_id`);

--
-- Index pour la table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`ne_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `chat`
--
ALTER TABLE `chat`
  MODIFY `ch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT pour la table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `ne_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
