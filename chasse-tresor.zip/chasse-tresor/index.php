<?php

require_once("inc/connexion.inc.php");
// CHARGER MES FONCTIONS
require_once("inc/functions.inc.php");

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>CHASSE AU TRESOR</title>
        <link rel="stylesheet" href="assets/css/chasse-tresor.css" type="text/css" />
    </head>
    <body>
        <header>
            <h1>CHASSE AU TRESOR</h1>
        </header>
        <main>
            <section>
                <!-- CARTE GOOGLE MAP -->
                <div id="map">
                    
                </div>
                
                <!-- QUESTIONNAIRE -->
                <div id="reponseQuestion">
                    <p>
CLIQUEZ SUR UN MARQUEUR POUR AFFICHER LA QUESTION                        
                    </p>
                    <div class="lieuInfo">
                        <h3 class="titre">TITRE</h3>
                        <h4>Description</h4>
                        <p class="description">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit,
                            sed diam nonummy nibh euismod tincidunt ut laoreet dolore
                            magna aliquam erat volutpat. Ut wisi enim ad minim veniam,
                            quis nostrud exerci tation ullamcorper suscipit lobortis nisl
                            ut aliquip ex ea commodo consequat. Duis autem vel eum iriure
                            dolor in hendrerit in vulputate velit esse molestie consequat,
                            vel illum dolore eu feugiat nulla facilisis at vero eros et
                            accumsan et iusto odio dignissim qui blandit praesent luptatum
                            zzril delenit augue duis dolore te feugait nulla facilisi.
                        </p>
                        <h4>Question</h4>
                        <p class="question">???</p>
                    </div>
                    
                    <form>
                        <h4>Réponse</h4>
                        <input type="text" name="reponse" required />
                        <input type="hidden" name="action" value="addReponse" />
                        <input type="submit" value="ENVOYER"/>
                    </form>
                </div>
            </section>
            <section>
                <!-- FORMULAIRE DE CREATION DE QUESTION -->
                <div id="addQuestion">
                    <p>
                        CREEZ UNE NOUVELLE QUESTION
                    </p>
                    <form class="ajax" action="libs/services.php" method="POST">
                        <div>
                            <input type="text" name="titre" placeholder="TITRE" required />
                        </div>
                        <div>
                            <input id="pac-input" class="controls" type="text" name="adresse" placeholder="ADRESSE DU LIEU" required />
                        </div>
                
                        <div>
                            <textarea type="text" name="description" placeholder="DESCRIPTION" cols="40" rows="5" required></textarea>
                        </div>
                        <div>
                            <input type="text" name="question" placeholder="QUESTION" required />
                        </div>
                        <div>
                            <input type="text" name="reponse" placeholder="REPONSE" required />
                        </div>
                        <div>
                            <input type="hidden" name="pseudo" value="auteur1" />
                            <input type="hidden" name="action" value="addLieu" />
                            <input type="submit" value="CREER LE LIEU"/>
                        </div>
                        <div class="retour">
                            <!-- ICI ON VERRA LE MESSAGE DE RETOUR -->
                        </div>
                    </form>
                </div>
                
                <!-- TOP LISTE DES JOUEURS -->
                <div id="topJoueur">
                    <h4>TOP SCORES JOUEURS</h4>
                    <div class="container-scores">
                        <ol>
                            <li>
                                <span class="pseudo">JOUEUR 1</span>
                                <span class="score">23</span>
                            </li>
                            <li>
                                <span class="pseudo">JOUEUR 2</span>
                                <span class="score">22</span>
                            </li>
                            <li>
                                <span class="pseudo">JOUEUR 3</span>
                                <span class="score">21</span>
                            </li>
                            <li>
                                <span class="pseudo">JOUEUR 4</span>
                                <span class="score">20</span>
                            </li>
                            <li>
                                <span class="pseudo">JOUEUR 5</span>
                                <span class="score">19</span>
                            </li>
                            <li>
                                <span class="pseudo">JOUEUR 6</span>
                                <span class="score">18</span>
                            </li>
                        </ol>
                    </div>
                </div>
            </section>
            
        </main>
        <footer>
            
        </footer>
        
        <script type="text/javascript">

var map;
var geocoder;

// CETTE FONCTION initMap SERA ACTIVEE PAR GOOGLE MAPS
// GRACE AU PARAMETRE GET &callback=initMap
function initMap() 
{
    map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 48.853, lng: 2.35},
        zoom: 11
    });

    // ON CREE L'OBJET QUI VA NOUS PERMETTRE DE RETROUVER UNE ADRESSE 
    geocoder = new google.maps.Geocoder();

    // ON AJOUTE L'AUTOCOMPLETION DES ADRESSES SUR LE CHAMP input#pac-input
    var input           = document.getElementById('pac-input');
    var autocomplete    = new google.maps.places.Autocomplete(input);
    
    // ON VA AJOUTER LES MARQUEURS DES PLACES FOURNIES PAR LA TABLE MYSQL Lieux
    ajouterListeMarker();
    
}

// RETROUVE LA POSITION LAT,LON A PARTIR D'UNE ADRESSE
// ET AJOUTE UN MARQUEUR SUR LA CARTE
// WARNING: NE FONCTIONNE PAS POUR TOUTES LES ADRESSES... :-/
function geocodeAddress(address, title, idLieu, geocoder, resultsMap) 
{
    geocoder.geocode({'address': address}, function(results, status) {
    if (status === google.maps.GeocoderStatus.OK) {
      var marker = new google.maps.Marker({
        map: resultsMap,
        title: title,
        position: results[0].geometry.location
      });
      
      marker.addListener("click", function() {
          $("#reponseQuestion .lieuInfo").load("libs/services.php", {action: "getLieuInfo", idLieu: idLieu });
          console.log(title + idLieu);
      });
      
    } else {
        console.log('Geocode was not successful for the following reason: ' + status);
    }
  });
}

var tabAddress  = [];
var tabTitle    = [];
var tabIdLieu   = [];

function ajouterListeMarker()
{
    for(var a=0; a < tabAddress.length; a++)
    {
        address = tabAddress[a];
        title   = tabTitle[a];
        idLieu  = tabIdLieu[a];
        // AJOUTE UN MARQUEUR SUR LA CARTE A PARTIR DE L'ADRESSE
        geocodeAddress(address, title, idLieu, geocoder, map);
    }
}


<?php
// CE SERA PHP QUI VA FOURNIR A JAVASCRIPT 
// LA LISTE DES ADRESSES A AJOUTER AVEC UN MARQUEUR
getLieuxJS();

?>
    </script>
    <!-- BIEN AJOUTER LE PARAMETRE &libraries=places POUR POUVOIR UTILISER L'API PLACES -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBoNltJRPfQ25IFdqOiECoffErQEUvqGQ0&libraries=places&callback=initMap"
        async defer></script>
    
    <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous">
    </script>
  
    <script type="text/javascript" src="assets/js/ajaxForm.js">
    </script>

    </body>
</html>