<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>CODE PRIVE AVEC JAVASCRIPT</title>
    </head>
    <body>
        <section>
            <h3>COMMENT FAIRE DU CODE PRIVE EN JS</h3>
            <script type="text/javascript">
// PROBLEMATIQUE
// COMMENT PROTEGER UNE PARTIE DE SON CODE
// POUR EMPECHER LES AUTRES CODEURS D'APPELER CERTAINES FONCTIONS
var monObjetPublic = (function(){
    // TEST
    console.log("FONCTION ACTIVEE");
    
    // CODE PRIVE
    // JE CREE UNE VARIABLE LOCALE (PRIVEES)
    var objetPublic = {};
    
    // SI JE VEUX AVOIR DU CODE PRIVE
    // JE LE METS DANS MA FONCTION
    var fairePrive = function () {
        console.log("ACTION PRIVEE");
    };
    
    var compteur = 0;
    
    // CODE PUBLIC
    // POUR RENDRE PUBLIC CERTAINES VARIABLES OU FONCTIONS
    // IL FAUT LES AJOUTER DANS objetPublic
    objetPublic.fairePublic = function () {
        console.log("ACTION PUBLIQUE");
        // JE PEUX ACTIVER LES FONCTIONS PRIVEES
        fairePrive();
        compteur = compteur +1; 
    };
    
    // JE RENVOIE LA VALEUR DE LA VARIABLE LOCALE
    return objetPublic;
})();

monObjetPublic.fairePublic();

// ERREUR
// ON NE PEUT PAS APPELER LA FONCTION fairePrive EN DEHORS DE LA FONCTION ANONYME
fairePrive();

            </script>
        </section>
    </body>
</html>