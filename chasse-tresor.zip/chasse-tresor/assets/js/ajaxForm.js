/*

POUR POUVOIR UTILISER LE CODE QUI SUIT
IL FAUT UNE STRUCTURE SPECIALE DE FORMULAIRE

<form class="ajax">

	<!-- ICI IL FAUT AJOUTER LES BALISES input -->

	<input type="hidden" name="action" value="addXXX" />
	<div class="retour">
	</div>
</form>

*/


// POUR UTILISER jQuery, JE METS MON CODE DANS CE BLOC D'INITIALISATION
$(function() 
{
	// JE VEUX PASSER MON FORMULAIRE DE NEWSLETTER EN AJAX
	// JE PRENDS LE CONTROLE SUR LE BOUTON D'ENVOI DU FORMULAIRE
	// DESACTIVER LE FONCTIONNEMENT NORMAL
	// JE VAIS RECUPERER LES INFOS DU FORMULAIRE (email)
	// ET JE VAIS LES ENVOYER PAR AJAX
	// ET JE VAIS RECUPERER LE MESSAGE DE RETOUR DANS LA BALISE .retour
	$("form.ajax").on("submit", function(e){
		// CE CODE SERA ACTIVE QUAND LE FORMULAIRE SERA ENVOYE
		// JE BLOQUE LE FONCTIONNEMENT NORMAL
		e.preventDefault();
		// JE VAIS RECUPERER email
		// http://api.jquery.com/val/
		// var email = $("form.newsletter input[name=email]").val();
		// JE CONSTRUIS A LA MAIN LA REQUETE GET A ENVOYER
		// var requeteGet = "libs/services.php?action=addNewsletter&email=" + email;
		// $(".retour").load(requeteGet);
		// http://api.jquery.com/serialize/
		var parametresGet  = $(this).serialize();
		var requeteGet 	   = "libs/services.php";
		// J'ENVOIE LA REQUETE EN AJAX
		$(this).find(".retour").load(requeteGet, parametresGet);
	});
});

