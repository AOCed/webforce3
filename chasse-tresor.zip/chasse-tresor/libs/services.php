<?php
// AJAX
// Asynchronous
// Javascript
// And
// XML

//var_dump($_POST);
//var_dump($_REQUEST);		// VA INCLURE $_GET ET $_POST

// JE VEUX ENREGISTRER L'EMAIL DANS UNE TABLE newsletter DANS UNE BDD ajax
// CODE POUR SE CONNECTER A LA BDD
require_once("../inc/connexion.inc.php");
// ON CHARGE TOUTES LES FONCTIONS
require_once("../inc/functions.inc.php");


switch($_REQUEST["action"])
{
	case "addLieu":
		addLieu();
		break;
	case "addNewsletter":
		addNewsletter();
		break;
	case "addChat":
		addChat();
		break;
	case "getLieuInfo":
		getLieuInfo();
		break;
	case "getChats":
		getChats();
		break;
	case "getDestinations":
		getDestinations();
		break;
	case "getSection":
		getSection();
		break;
	case "getJSON":
		getJSON();
		break;
	default:
		echo "SERVICE NON DEFINI";
		break;
}


function addLieu()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;
	// RECUPERER LES INFOS DU FORMULAIRE
	$titre 			= $_REQUEST["titre"];
	$description	= $_REQUEST["description"];
	$adresse 		= $_REQUEST["adresse"];
	$question 		= $_REQUEST["question"];
	$reponse 		= $_REQUEST["reponse"];
	$pseudo 		= $_REQUEST["pseudo"];
	// COMPLETER LES INFOS
	$date			= date("Y-m-d H:i:s");

	// VERIFICATION DE SECURITE
	if (!empty($pseudo) && !empty($titre) && !empty($description) && !empty($adresse) && !empty($question) && !empty($reponse))
	{
		// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
		$data = 
			[ 
				"titre" 		=> $titre,  
				"description" 	=> $description,  
				"adresse" 		=> $adresse,  
				"question" 		=> $question,  
				"reponse" 		=> $reponse,  
				"pseudo" 		=> $pseudo,  
				"date" 			=> $date,  
			];

		// REQUETE SQL POUR AJOUTER UNE LIGNE
		// HEREDOC PERMET DE NE PAS UTILISER "..."
		// http://php.net/manual/fr/language.types.string.php#language.types.string.syntax.heredoc
		$sql = 
<<<CODESQL
INSERT INTO lieux 
( li_titre, li_description, li_adresse, li_question, li_reponse, li_pseudo, li_date ) 
VALUES 
( :titre, :description, :adresse, :question, :reponse, :pseudo, :date );";
CODESQL;

		// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
		$req = $connexion->prepare($sql);
		// EXECUTER LA REQUETE
		$req->execute($data);

		// RECUPERER L'id
		// http://php.net/manual/fr/pdo.lastinsertid.php
		$idLieu = $connexion->lastInsertId();
		
		// MESSAGE DE RETOUR
		echo
<<<CODEHTML
		<div>$pseudo a écrit: $titre</div>
	<script type="text/javascript">
geocodeAddress("$adresse", "$titre", $idLieu, geocoder, map);

	</script>
CODEHTML;

	}
	else
	{
		echo "INFORMATION MANQUANTE";
	}
}


function getJSON ()
{
	// COTE PHP ON A DE L'INFORMATION DANS UN TABLEAU ASSOCIATIF
	$tabAssoc = 
	[
		"nom"		=> "maurice",
		"prenom"	=> "albert"
	];
	// JE VAIS TRANSFORMER CE TABLEAU ASSOCIATIF EN TEXTE AU FORMAT JSON
	// http://php.net/manual/en/function.json-encode.php
	$texteJSON = json_encode($tabAssoc);
	
	// ENVOYER LE TEXTE JSON AU NAVIGATEUR
	echo $texteJSON;
}

function addChat()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;
	// RECUPERER LES INFOS DU FORMULAIRE
	$pseudo 	= $_REQUEST["pseudo"];
	$message 	= $_REQUEST["message"];
	// COMPLETER LES INFOS
	$date		= date("Y-m-d H:i:s");

	// VERIFICATION DE SECURITE
	if (!empty($pseudo) && !empty($message))
	{
		// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
		$data = 
			[ 
				"pseudo" 	=> $pseudo,  
				"message" 	=> $message,  
				"date" 		=> $date,  
			];

		// REQUETE SQL POUR AJOUTER UNE LIGNE
		$sql = "INSERT INTO chat ( ch_pseudo, ch_message, ch_date ) VALUES ( :pseudo, :message, :date );";

		// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
		$req = $connexion->prepare($sql);
		// EXECUTER LA REQUETE
		$req->execute($data);

		// MESSAGE DE RETOUR
		// echo "$pseudo a écrit: $message";
	}

	// ON AFFICHE TOUS LES MESSAGES
	getChats();
}

function addNewsletter()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;
	// RECUPERER LES INFOS DU FORMULAIRE
	$email = $_REQUEST["email"];

	// VERIFICATION DE SECURITE
	if (!empty($email) && (filter_var($email, FILTER_VALIDATE_EMAIL) !== false) )
	{
		// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
		$data = [ "email" => $email ];

		// REQUETE SQL POUR AJOUTER UNE LIGNE
		$sql = "INSERT INTO newsletter ( ne_email ) VALUES ( :email );";

		// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
		$req = $connexion->prepare($sql);
		// EXECUTER LA REQUETE
		$req->execute($data);

		// MESSAGE DE RETOUR
		echo "MERCI DE VOTRE INSCRIPTION AVEC $email";
	}
}