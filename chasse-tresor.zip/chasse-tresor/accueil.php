<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>AJAX</title>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	</head>
	<body>
		<header>
			<h1>AJAX</h1>
		</header>
		<main>
<section>
	<h2>PAGE SIMPLE <?php echo date("H:i:s") ?></h2>
	<div class="contenu">
		CECI EST DU CONTENU STATIQUE CHANGE
	</div>
</section>		
<section>
	<h2>PAGE SIMPLE AVEC DU CONTENU MODIFIE PAR AJAX</h2>
	<div class="contenu2">
		CECI EST DU CONTENU STATIQUE QUI VA CHANGER
	</div>
	<p>AJAX PERMET DE CHARGER DU CONTENU DEPUIS LE SERVEUR SANS RECHARGER TOUTE LA PAGE</p>
</section>		
<section>
	<h2 class="bouton3">PAGE SIMPLE AVEC DU CONTENU MODIFIE PAR AJAX</h2>
	<div class="contenu3">
		CECI EST DU CONTENU STATIQUE QUI VA CHANGER
	</div>
	<p>AJAX PERMET DE CHARGER DU CONTENU DEPUIS LE SERVEUR SANS RECHARGER TOUTE LA PAGE</p>
</section>		

		</main>
		<footer>
			<p>tous droits réservés 2017</p>
		</footer>

<script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
<script type="text/javascript">
alert("attention, le contenu2 va changer");

// POUR UTILISER jQuery, JE METS MON CODE DANS CE BLOC D'INITIALISATION
$(function() 
{
	// CODE QUI VA ETRE ACTIVE QUAND LA PAGE SERA PRETE

	// JE VAIS CHANGER LE CONTENU LA BALISE contenu2
	// SANS RECHARGER LA PAGE
	$(".contenu2").load("ajax-contenu2.php");

	// JE VEUX QUE SI ON CLIQUE SUR LE h2.bouton3 
	// ALORS ON CHARGE DU CONTENU PAR AJAX
	$(".bouton3").on("click", function(){
		$(".contenu3").load("ajax-contenu3.php");
	});
});

</script>
	</body>
</html>