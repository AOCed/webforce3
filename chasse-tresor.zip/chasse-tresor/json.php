<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>AJAX AVEC JSON</title>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	</head>
	<body>
		<header>
			<h1>AJAX AVEC JSON</h1>
		</header>
		<main>
<section>
	<h2>AJAX AVEC DU JSON</h2>
	<div class="contenu2">
		CECI EST DU CONTENU STATIQUE QUI VA CHANGER
	</div>
</section>		
		</main>
		<footer>
			<p>tous droits réservés 2017</p>
		</footer>

<!-- CHARGER LE CODE DE JQUERY -->
<script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
  
<script type="text/javascript">

// POUR UTILISER jQuery, JE METS MON CODE DANS CE BLOC D'INITIALISATION
$(function() 
{
    // CE CODE SERA ACTIVE QUAND LA PAGE SERA PRETE
    // ON VA UTILISER $.getJSON POUR CHARGER DU CONTENU AU FORMAT JSON DEPUIS LE SERVEUR
    // http://api.jquery.com/jquery.getjson/
    $.getJSON("libs/services.php", { "action" : "getJSON" })
    .done(function() {
        console.log( "second success" );
    })
    .done(function (dataJSON){
        // CE CODE SERA ACTIVE QUAND LA PAGE WEB VA RECEVOIR LA REPONSE DU SERVEUR
        
        // JQUERY TRANSFORME LE TEXTE RECU DU SERVEUR EN UN OBJET JAVASCRIPT
        // ON CONSTRUIT LE CODE HTML QU'ON VEUT UTILISER POUR AFFICHER L'INFORMATION
        var codeHTML = "<h3>" + dataJSON.prenom  + " " + dataJSON.nom + "</h3>";

        // JE VAIS INSERER LE CODE HTML CONSTRUIT DANS LA BALISE .contenu2
        $(".contenu2").html(codeHTML);
    })
    .fail(function() {
        console.log( "error" );
    })
    .always(function() {
        console.log( "complete" );
    })
  ;
    
});

</script>
	</body>
</html>