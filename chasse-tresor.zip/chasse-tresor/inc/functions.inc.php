<?php

// DECLARATION DE LA FONCTION
// CE QUE MON PROGRAMME SAIT FAIRE


function getLieuInfo ()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;

	// RECUPERER LES INFOS DU FORMULAIRE
	$idLieu = intval($_REQUEST["idLieu"]);
	
	// VERIFICATION DE SECURITE
	// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
	$data = [];

	// REQUETE SQL POUR AJOUTER UNE LIGNE
	$sql = "SELECT * FROM lieux WHERE li_id = $idLieu";

	// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
	$req = $connexion->prepare($sql);
	// EXECUTER LA REQUETE
	$req->execute($data);

	// MESSAGE DE RETOUR
	// LECTURE DES LIGNES TROUVEES
	// PARCOURS DE CHAQUE LIGNE UNE PAR UNE
	$compteur = 0;
	while ($datas = $req->fetch(PDO::FETCH_ASSOC))
	{
		// RECUPERER LES INFOS DES COLONNES
		$id     		= $datas["li_id"];
		$titre  		= $datas["li_titre"];
		$adresse		= $datas["li_adresse"];
		$description	= $datas["li_description"];
		$question		= $datas["li_question"];
		
		// CONSTRUIRE LE CODE JS
		echo 
<<<CODEHTML
<h4>$titre</h4>
<strong>$adresse</strong>
<p>$description</p>
<h4>Question</h4>
<h4>$question</h4>
CODEHTML;
		$compteur++;
	}

}


function getLieuxJS ()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;

	// VERIFICATION DE SECURITE
	// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
	$data = [];

	// REQUETE SQL POUR AJOUTER UNE LIGNE
	$sql = "SELECT * FROM lieux ORDER BY li_date DESC";

	// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
	$req = $connexion->prepare($sql);
	// EXECUTER LA REQUETE
	$req->execute($data);

	// MESSAGE DE RETOUR
	// LECTURE DES LIGNES TROUVEES
	// PARCOURS DE CHAQUE LIGNE UNE PAR UNE
	$compteur = 0;
	while ($datas = $req->fetch(PDO::FETCH_ASSOC))
	{
		// RECUPERER LES INFOS DES COLONNES
		$adresse = $datas["li_adresse"];
		$titre   = $datas["li_titre"];
		$id      = $datas["li_id"];
		
		// CONSTRUIRE LE CODE JS
		echo 
<<<CODEJS
tabAddress[$compteur] = "$adresse";
tabTitle[$compteur]   = "$titre"; 
tabIdLieu[$compteur]  = "$id"; 

CODEJS;
		$compteur++;
	}

}

function getSection ()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;

	// RECUPERER LES INFOS DU FORMULAIRE
	$idSection = $_REQUEST["idSection"];
	
	// ON VA CONSIDERER $idSection COMME LE NUMERO DE PAGE A AFFICHER
	// ON DECALE DE 1 VERS 0 POUR AVOIR L'INDEX DE LA PAGE
	$indexPage = intval($idSection) -1;
	if ($indexPage < 0) 
	{
		$indexPage = 0;
	}
	
	// ON AFFICHE 5 LIGNES PAR PAGE
	$nbLigneParPage = 5;
	$indexDepart	= $indexPage * $nbLigneParPage;
	
	// REQUETE SQL POUR LIRE LES LIGNES PAGINEES
	$sql = "SELECT * FROM chat  ORDER BY ch_date DESC LIMIT $indexDepart, $nbLigneParPage";

	// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
	$req = $connexion->prepare($sql);
	// EXECUTER LA REQUETE
	$req->execute($data);

	// MESSAGE DE RETOUR
	// LECTURE DES LIGNES TROUVEES
	// PARCOURS DE CHAQUE LIGNE UNE PAR UNE
	while ($datas = $req->fetch())
	{
		$id 		= $datas["ch_id"];
		$pseudo 	= $datas["ch_pseudo"];
		$message	= $datas["ch_message"];
		$date		= $datas["ch_date"];
		
		echo 
<<<CODEHTML
	<div class="ligne"><small>($id)[$date]</small> $pseudo : $message</div>
CODEHTML;

	}


}

function getDestinations ()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;

	// RECUPERER LES INFOS DU FORMULAIRE
	$destination = $_REQUEST["destination"];
	
	// UN PEU DE SECURITE
	if (!empty($destination))
	{
		// VERIFICATION DE SECURITE
		// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
		// ON AJOUTE % POUR CHERCHER TOUS LES NOMS QUI COMMENCENT PAR CE QUE LE VISITEUR A ENTRE
		$data = [ "destination" => "$destination%" ];
	
		// REQUETE SQL POUR AJOUTER UNE LIGNE
		$sql = "SELECT * FROM destination WHERE de_ville LIKE :destination";
	
		// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
		$req = $connexion->prepare($sql);
		// EXECUTER LA REQUETE
		$req->execute($data);
	
		// MESSAGE DE RETOUR
		// LECTURE DES LIGNES TROUVEES
		// PARCOURS DE CHAQUE LIGNE UNE PAR UNE
		while ($datas = $req->fetch())
		{
			echo '<div class="ville">' . $datas["de_ville"] . ' : ' . $datas["de_pays"] . '</div>';
		}
	}
}

function getChats ()
{
	// JE VEUX UTILISER LA CONNEXION DEJA CREEE
	global $connexion;

	// VERIFICATION DE SECURITE
	// TABLEAU ASSOCIATIF DES INFOS A ENREGISTRER DANS LA TABLE newsletter
	$data = [];

	// REQUETE SQL POUR AJOUTER UNE LIGNE
	$sql = "SELECT * FROM chat ORDER BY ch_date DESC";

	// PREPARER LA REQUETE (PROTECTION CONTRE LES INJECTIONS SQL)
	$req = $connexion->prepare($sql);
	// EXECUTER LA REQUETE
	$req->execute($data);

	// MESSAGE DE RETOUR
	// LECTURE DES LIGNES TROUVEES
	// PARCOURS DE CHAQUE LIGNE UNE PAR UNE
	while ($datas = $req->fetch())
	{
		echo '<p>' . $datas["ch_pseudo"] . ' : ' . $datas["ch_message"] . '</p>';
	}

}