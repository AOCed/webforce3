<?php

// INFOS A CHANGER A CHAQUE PROJET
$host 		= "localhost";
$dbname 	= "ajax";
$user 		= "root";
$password 	= "";

try 
{
	// http://php.net/manual/fr/pdo.construct.php
	$connexion = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
}
catch (PDOException $e) 
{
    echo 'Connexion échouée : ' . $e->getMessage();
}
