<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>AJAX</title>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	</head>
	<body>
		<header>
			<h1>AJAX</h1>
		</header>
		<main>
<section>
	<h2>FORMULAIRE DE NEWSLETTER</h2>
	<form class="newsletter ajax" action="libs/services.php" method="POST">
		<input type="email" placeholder="ENTREZ VOTRE EMAIL" name="email" required />
		<input type="submit" value="INSCRIPTION" />
		<input type="hidden" name="action" value="addNewsletter" />
		<div class="retour">
		<!--ICI ON VERRA LE MESSAGE DE RETOUR-->
		</div>
	</form>
</section>		
	

		</main>
		<footer>
			<p>tous droits réservés 2017</p>
		</footer>

<script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
  
<script type="text/javascript" src="assets/js/ajaxForm.js">
</script>
	</body>
</html>