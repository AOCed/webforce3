<?php 
// mktime permet de convertir une date en timestamp
$dateDeNaissance = date('d/m/Y',mktime(00,00,00,2,20,1993));

$infosUtilisateur = array(
	'Prénom'            => 'Thomas',
	'Nom'               => 'Mion',
	'Adresse'           => '54, rue quelque part',
	'Code Postal'       => 14320,
	'Ville'             => 'Paris',
	'Email'             => 'th.mion@gmail.com',
	'Téléphone'         => '08.63.25.14.58',
	'Date de naissance' => $dateDeNaissance
);

echo '<ul>';
// On lance une boucle qui itère sur chaque entrée du tableau infosUtilisateur
foreach ($infosUtilisateur as $key => $value ) {
	echo '<li>' . $key . ' : ' . $value . '</li>';
}
echo '</ul>';
?>