--
-- Base de données :  `exercice_3`
--

-- --------------------------------------------------------

--
-- Structure de la table `movies`
--

CREATE TABLE `movies` (
  `movie_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `actors` varchar(255) NOT NULL,
  `director` varchar(100) NOT NULL,
  `producer` varchar(100) NOT NULL,
  `year_of_prod` year(4) NOT NULL,
  `language` varchar(100) NOT NULL,
  `category` enum('Action','Comédie','Romance','Familial','Horreur','Guerre','Fantastique','Thriller') NOT NULL,
  `storyline` text NOT NULL,
  `video` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `movies`
--

INSERT INTO `movies` (`movie_id`, `title`, `actors`, `director`, `producer`, `year_of_prod`, `language`, `category`, `storyline`, `video`) VALUES
(2, 'Le silence des anneaux', 'Vin Diesel, Emma Stone', 'Ewan McGregor', 'Charles McBaldwin', 2014, 'Anglais', 'Action', 'Dans un monde où les anneaux sont incapables de parler, UN HOMME fera tout pour empêcher la destruction du monde.', ''),
(3, 'Matraque', 'Keanu Reeves', 'Lana Wachowski et Lilly Wachowski', 'Agent Smith', 1999, 'Anglais', 'Action', 'Programmeur anonyme dans un service administratif le jour, Thomas Anderson devient Neo la nuit venue. Sous ce pseudonyme, il est l''un des pirates les plus recherchés du cyber-espace. A cheval entre deux mondes, Neo est assailli par d''étranges songes et des messages cryptés provenant d''un certain Morpheus. Celui-ci l''exhorte à aller au-delà des apparences et à trouver la réponse à la question qui hante constamment ses pensées : qu''est-ce que la Matraque ? Nul ne le sait, et aucun homme n''est encore parvenu à en percer les défenses. Mais Morpheus est persuadé que Neo est l''Élu, le libérateur mythique de l''humanité annoncé selon la prophétie. Ensemble, ils se lancent dans une lutte sans retour contre la Matrice et ses terribles agents...', ''),
(4, 'L''Effet Pangolin', 'Ashton Kutcher, Kirsten Dunst', 'Un bonsaï', 'Sam West', 2004, 'Français', 'Fantastique', 'JAMES (Ashton Kutcher) se réveille un jour avec un pangolin à la place de la jambe gauche. Hilarity ensues!', 'http://www.google.fr'),
(5, 'Un jour sans début', 'Bill Murray, Jim Carrey', 'Anno Hideaki', 'Bioware', 2009, 'Anglais', 'Comédie', 'JACK STALION (Bill Murray) doit couvrir un reportage sur "Le jour du panda", un festival organisé tous les ans à Sichuan, en Chine. Là-bas, il rencontre son ancien prof d''art-plastique, MULDER RAIN (Jim Carrey)...', 'http://www.google.fr'),
(10, 'La légende du cavalier sans épaule gauche (Remake)', 'Dan Hale, Alisson Brie', 'Didier Bourdon', 'Alain Chabat', 2016, 'Russe', 'Familial', 'Une légende...\r\nUn cavalier...\r\nUne épaule solitaire...\r\n\r\nUN FILM', '');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`movie_id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `movies`
--
ALTER TABLE `movies`
  MODIFY `movie_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
