<?php
$root_path = '..';
require_once($root_path . '/inc/init_session.inc.php');

if (!empty($_GET['action'])) {
	switch($_GET['action']) {
		case 'addMovie':
			addMovie();
			break;
			
		default : break;
	}
}

if (!empty($_SERVER['HTTP_REFERER'])) {	
	header('Location:' . $_SERVER['HTTP_REFERER']);
} else {
	header('Location:' . $root_path . '/');
}
die();

function addMovie() {
	global $connexion, $root_path;

	if (strlen($_POST['title']) >= 5 && strlen($_POST['director']) >= 5 && strlen($_POST['actors']) >= 5 && strlen($_POST['producer']) >= 5 && strlen($_POST['storyline']) >= 5 && (filter_var($_POST['video'], FILTER_VALIDATE_URL) || empty($_POST['video']))) {
		$data = array(
			'title'        => $_POST['title'],
			'director'     => $_POST['director'],
			'actors'       => $_POST['actors'],
			'producer'     => $_POST['producer'],
			'storyline'    => $_POST['storyline'],
			'year_of_prod' => $_POST['year_of_prod'],
			'language'     => $_POST['language'],
			'category'     => $_POST['category'],
			'video'        => $_POST['video']
		);

		$sql = "INSERT INTO movies (title, director, actors, producer, storyline, year_of_prod, language, category, video) VALUES (:title, :director, :actors, :producer, :storyline, :year_of_prod, :language, :category, :video)";

		$req = $connexion->prepare($sql);
		$req->execute($data);

		$_SESSION['lastAction'] = 'addMovie';

		header('Location:' . $root_path . '/?page=fiche&id=' . $connexion->lastInsertId());
		exit;
	} else {
		// On initialise la variable error qu'on enverra en paramètre GET et qui nous servira plus tard à déterminer les messages d'erreur à afficher
		$error = '';

		// On attribue un chiffre à chaque erreur possible
		// Dans la page edit.inc.php, on vérifiera la présence de "x" dans la variable $_GET['error']
		// Si 1, c'est que le titre fait moins de 5 caractères, si 2, c'est que le directeur fait moins de 5 caractères... etc
		if (strlen($_POST['title']) < 5) {
			$error .= '1';
		}

		if (strlen($_POST['director']) < 5) {
			$error .= '2';
		}

		if (strlen($_POST['producer']) < 5) {
			$error .= '3';
		}

		if (strlen($_POST['actors']) < 5) {
			$error .= '4';
		}

		if (strlen($_POST['storyline']) < 5) {
			$error .= '5';
		}

		if (!filter_var($_POST['video'], FILTER_VALIDATE_URL) && !empty($_POST['video'])) {
			$error .= '6';
		}

		// Pour éviter à l'utilisateur de retaper tout ce qu'il avait entré, on enregistre en session ses entrées
		$_SESSION['movie']['title']        = $_POST['title'];
		$_SESSION['movie']['director']     = $_POST['director'];
		$_SESSION['movie']['producer']     = $_POST['producer'];
		$_SESSION['movie']['actors']       = $_POST['actors'];
		$_SESSION['movie']['storyline']    = $_POST['storyline'];
		$_SESSION['movie']['year_of_prod'] = $_POST['year_of_prod'];
		$_SESSION['movie']['language']     = $_POST['language'];
		$_SESSION['movie']['category']     = $_POST['category'];
		$_SESSION['movie']['video']        = $_POST['video'];		

		header('Location:' . $root_path . '/?page=edit&error='.$error);
		die();
	}

	exit;
}
?>