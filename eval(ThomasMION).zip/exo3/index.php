<?php
$page_title = 'Accueil';
$root_path = '.';

require_once($root_path . '/inc/init_session.inc.php');
include($root_path . '/inc/header.inc.php');
?>
	<main>

		<?php 
			// On appelle la Vue correspondant à la page demandée
			if (!empty($_GET['page'])) { // Si l'utilisateur cherche à atteindre une page...
				if (file_exists($root_path . '/inc/pages/' . $_GET['page'] . '.inc.php')) { // On vérifie si elle existe : si oui, on l'inclut
					include($root_path . '/inc/pages/' . $_GET['page'] . '.inc.php');		
				} else { // Sinon, on inclut la page erreur 404
					include($root_path . '/inc/pages/404.inc.php');		
				}
			} else { // Sinon, c'est que l'utilisateur est sur la page d'accueil
				include($root_path . '/inc/pages/home.inc.php');
			}
		?>

		<?php include($root_path . '/inc/footer.inc.php'); ?>

	</main>

	<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
	<script type="text/javascript" src="js/main.js"></script>