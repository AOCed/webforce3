<section>
	<h2>Accueil</h2>
	<p>
		Bienvenues sur MovieDB.
	</p>
</section>