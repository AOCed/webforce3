<?php 	
	$movies = getFromDb('movies', 'year_of_prod');
?>

<section>
	<h2>Collection</h2>

	<?php if ($movies) { ?>

		<table id="moviesList">
			<tr>
				<th>Titre</th>
				<th>Réalisateur</th>
				<th>Année de production</th>
				<th></th>
			</tr>
		<?php 
			foreach ($movies as $movie) {
				?>
				<tr>
					<td><?php echo $movie['title']; ?></td>
					<td><?php echo $movie['director']; ?></td>
					<td><?php echo $movie['year_of_prod']; ?></td>
					<td><a href="<?php echo $root_path; ?>/index.php?page=fiche&id=<?php echo $movie['movie_id']; ?>">Consulter la fiche</a></td>
				</tr>
				<?php
			}
		?>
		</table>

	<?php } else { ?>
		<p>Malheureusement, aucun film n'a été trouvé dans la base de données.</p>
	<?php } ?>
</section>