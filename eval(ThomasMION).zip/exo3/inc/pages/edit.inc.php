<?php 
$form_href = $root_path . '/libs/services.php?action=';

if (!empty($_GET['id'])) {
	$form_href  .= 'updateMovie';
	$action_name = 'Modifier';
} else {
	$form_href  .= 'addMovie';
	$action_name = 'Ajouter';
}

if (!empty($_GET['error'])) {
	$movie = array(
		'title'        => $_SESSION['movie']['title'],
		'director'     => $_SESSION['movie']['director'],
		'producer'     => $_SESSION['movie']['producer'],
		'actors'       => $_SESSION['movie']['actors'],
		'storyline'    => $_SESSION['movie']['storyline'],
		'year_of_prod' => $_SESSION['movie']['year_of_prod'],
		'language'     => $_SESSION['movie']['language'],
		'category'     => $_SESSION['movie']['category'],
		'video'        => $_SESSION['movie']['video'],
	);

	// Pour chaque erreur possible dans le formulaire, on vérifie si elle existe et si oui, on l'initialise dans un array dédié
	for ($i = 1 ; $i <= 6 ; $i++) {
		if (strpos($_GET['error'], strval($i)) !== false) {
			$error[$i] = true;
		}
	}
} else {
	$movie = array(
		'title'        => '',
		'director'     => '',
		'producer'     => '',
		'actors'       => '',
		'storyline'    => '',
		'year_of_prod' => '',
		'language'     => '',
		'category'     => '',
		'video'        => ''
	);
}
?>

<section>
	<h2><?php echo $action_name; ?> un film</h2>

	<form action="<?php echo $form_href; ?>" method="post">

		<div>
			<label for="title">Titre du film <span>(5 caractères minimum)</span></label>
			<input type="text" name="title" id="title" value="<?php echo $movie['title']; ?>" />
			<?php if (isset($error[1])) { ?>
				<p class="form-error">
					Vous devez au moins utiliser <strong>5</strong> caractères.
				</p>
			<?php } ?>
		</div>

		<div>
			<label for="director">Nom du réalisateur <span>(5 caractères minimum)</span></label>
			<input type="text" name="director" id="director" value="<?php echo $movie['director']; ?>" />
			<?php if (isset($error[2])) { ?>
				<p class="form-error">
					Vous devez au moins utiliser <strong>5</strong> caractères.
				</p>
			<?php } ?>
		</div>

		<div>
			<label for="producer">Producteur <span>(5 caractères minimum)</span></label>
			<input type="text" name="producer" id="producer" value="<?php echo $movie['producer']; ?>" />
			<?php if (isset($error[3])) { ?>
				<p class="form-error">
					Vous devez au moins utiliser <strong>5</strong> caractères.
				</p>
			<?php } ?>
		</div>

		<div>
			<label for="actors">Acteurs <span>(5 caractères minimum)</span></label>
			<input type="text" name="actors" id="actors" value="<?php echo $movie['actors']; ?>" />
			<?php if (isset($error[4])) { ?>
				<p class="form-error">
					Vous devez au moins utiliser <strong>5</strong> caractères.
				</p>
			<?php } ?>
		</div>

		<div>
			<label for="storyline">Synopsis <span>(5 caractères minimum)</span></label>
			<textarea name="storyline" id="storyline"><?php echo $movie['storyline']; ?></textarea>
			<?php if (isset($error[5])) { ?>
				<p class="form-error">
					Vous devez au moins utiliser <strong>5</strong> caractères.
				</p>
			<?php } ?>
		</div>

		<div class="select">
			<label for="year_of_prod">Année de production</label>
			<select name="year_of_prod" id="year_of_prod">
				<?php 
					for ($i = 1920 ; $i <= date("Y") ; $i++) {
						?>
						<option value="<?php echo $i; ?>"><?php echo $i; ?></option>
						<?php
					}
				?>
			</select>
		</div>

		<div class="select">
			<label for="language">Langue</label>
			<select name="language" id="language">
				<option value="Anglais">Anglais</option>
				<option value="Français">Français</option>
				<option value="Allemand">Allemand</option>
				<option value="Italien">Italien</option>
				<option value="Espagnol">Espagnol</option>
				<option value="Russe">Russe</option>
				<option value="Japonais">Japonais</option>
			</select>
		</div>

		<div class="select">
			<label for="category">Catégorie</label>
			<select name="category" id="category">
				<option value="Action">Action</option>
				<option value="Comédie">Comédie</option>
				<option value="Romance">Romance</option>
				<option value="Familial">Familial</option>
				<option value="Horreur">Horreur</option>
				<option value="Guerre">Guerre</option>
				<option value="Fantastique">Fantastique</option>
				<option value="Thriller">Thriller</option>
			</select>
		</div>

		<div>
			<label for="video">Lien de la bande-annonce <span>(Optionnel)</span></label>
			<input type="text" name="video" id="video" value="<?php echo $movie['video']; ?>" />
			<?php if (isset($error[6])) { ?>
				<p class="form-error">
					Cette adresse est invalide.
				</p>
			<?php } ?>
		</div>

		<div>
			<input type="submit" />
		</div>

	</form>

</section>