<section>
	<h1>On a perdu ta page :(</h1>
	<p>
		Erreur 404 : La page demandée n'existe pas ou plus.
	</p>
</section>