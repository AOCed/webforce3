<?php 
if (!empty($_GET['id'])) {
	$movie = getMovie($_GET['id']);	
}
?>
<section>
	<?php 
	if (!empty($_SESSION['lastAction']) && $_SESSION['lastAction'] === 'addMovie') { 
	?>
		<p class="congrats-msg">
			Félicitations, votre film a bien été ajouté à la base de données !
		</p>
	<?php 
		unset($_SESSION['lastAction']);
	} 
	?>
	<a href="index.php?page=list">Revenir à la liste des films</a>

	<?php if ($movie) { ?>
		<h2><?php echo $movie['title']; ?></h2>

		<h3>Fiche technique</h3>
		<dl>
			<dt>Date de sortie</dt> <dd><?php echo $movie['year_of_prod']; ?></dd>
			<dt>Genre</dt> <dd><?php echo $movie['category']; ?></dd>
			<dt>Réalisateur</dt> <dd>  <?php echo $movie['director']; ?></dd>
			<dt>Producteur</dt> <dd>  <?php echo $movie['producer']; ?></dd>
			<dt>Acteurs</dt> <dd>  <?php echo $movie['actors']; ?></dd>
			<dt>Langue</dt> <dd> <?php echo $movie['language']; ?></dd>	
		</dl>

		<h3>Synopsis</h3>
		<p>
			<?php echo nl2br($movie['storyline']); ?>
		</p>

		<h3>Bande-annonce</h3>
		<p>
			<?php if (!empty($movie['video'])) { ?>
				<a href="<?php echo $movie['video']; ?>">Voir la bande-annonce</a>
			<?php } else { ?>
				Aucune bande-annonce n'a été trouvée pour ce film.
			<?php } ?>
		</p>
	<?php } else { ?>
		<p>Malheureusement, cette fiche n'existe pas ou plus.</p>
	<?php } ?>
</section>