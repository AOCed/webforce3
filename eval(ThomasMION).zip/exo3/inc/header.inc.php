<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf-8" />
	<title><?php echo $page_title . ' - ' . SITE_NAME; ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo $root_path; ?>/css/styles.css" />
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
</head>

<body>

<h1><?php echo SITE_NAME; ?></h1>

<header>
	<nav>
		<ul>
			<li class="<?php if (!isset($_GET['page']) || $_GET['page'] === 'home') echo 'current'; ?>"><a href="<?php echo $root_path; ?>/index.php?page=home">Accueil</a></li>
			<li class="<?php if (isset($_GET['page']) && ($_GET['page'] === 'list' || $_GET['page'] === 'fiche')) echo 'current'; ?>"><a href="<?php echo $root_path; ?>/index.php?page=list">Collection</a></li>
			<li class="<?php if (isset($_GET['page']) && $_GET['page'] === 'edit') echo 'current'; ?>"><a href="<?php echo $root_path; ?>/index.php?page=edit">Ajouter un film</a></li>
		</ul>
	</nav>
</header>