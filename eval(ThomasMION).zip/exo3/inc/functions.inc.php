<?php
function getFromDb($table, $order = '') {
    global $connexion;

    if (!empty($order)) {
        $order = 'ORDER BY ' . $order;
    }

    $sql = "SELECT * FROM $table $order";

    $req = $connexion->query($sql);

    return $req->fetchAll(PDO::FETCH_ASSOC);
}

function getMovie($movieId) {
    global $connexion;

    $sql = "SELECT * FROM MOVIES WHERE movie_id = $movieId";

    $req = $connexion->query($sql);

    return $req->fetch(PDO::FETCH_ASSOC);
}
?>