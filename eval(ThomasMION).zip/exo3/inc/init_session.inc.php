<?php 
session_start();

require_once($root_path . '/inc/configuration.inc.php');
require_once($root_path . '/inc/connexion.inc.php');
require_once($root_path . '/inc/functions.inc.php');
?>