<?php 
define('SITE_NAME',"Movies DB");
