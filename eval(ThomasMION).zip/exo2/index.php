<?php 
/**
*
* @return
*/
function convertDollarEuro($montant, $devise) {
	if (!is_numeric($montant)) { // Si le montant n'est pas un nombre, on arrête la fonction
		return;
	}

	switch ($devise) {
		case 'USD':
			$taux = 0.95746;
			break;

		case 'EUR':
			$taux = 1.04444;
			break;

		default : break;
	}

	// round() permet d'arrondir à la précision souhaitée (ici deux chiffres après la virgule)
	return round($montant * $taux,2);
}
?>

<strong>Convertion Euros -> Dollars</strong>
<form action="" method="post">
	<input type="hidden" name="devise" value="EUR" />

	<label for="montant">Montant en €</label>
	<input type="text" name="montant" id="montant" value="<?php echo (isset($_POST['devise']) && $_POST['devise'] == 'EUR') ? $_POST['montant'] : '' ?>" />
	<input type="submit" />

</form>

<?php 
	if (!empty($_POST['montant']) && $_POST['devise'] === 'EUR') { 
		$conversion = convertDollarEuro($_POST['montant'], $_POST['devise']);
?>
	<p>
		<?php if ($conversion) { ?>
			<?php echo $_POST['montant']; ?>€ = <?php echo convertDollarEuro($_POST['montant'], $_POST['devise']); ?> USD
		<?php } else { ?>
			Vous devez rentrer une valeur numérique pour le montant.
		<?php } ?>
	</p>
<?php } ?>

<strong>Convertion Dollars -> Euros</strong>
<form action="" method="post">
	<input type="hidden" name="devise" value="USD" />

	<label for="montant">Montant en $</label>
	<input type="text" name="montant" id="montant" value="<?php echo (isset($_POST['devise']) && $_POST['devise'] === 'USD') ? $_POST['montant'] : '' ?>" />
	<input type="submit" />

</form>

<?php 
	if (!empty($_POST['montant']) && $_POST['devise'] === 'USD') { 
		$conversion = convertDollarEuro($_POST['montant'], $_POST['devise']);
?>
	<p>
		<?php if ($conversion) { ?>
			<?php echo $_POST['montant']; ?> USD = <?php echo convertDollarEuro($_POST['montant'], $_POST['devise']); ?>2€
		<?php } else { ?>
			Vous devez rentrer une valeur numérique pour le montant.
		<?php } ?>
	</p>
<?php } ?>