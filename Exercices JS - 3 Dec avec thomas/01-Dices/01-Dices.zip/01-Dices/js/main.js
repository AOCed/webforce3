$(document).ready(function() {
	function randomNumber(min, max) {
		// Cette fonction permet de générer un nombre aléatoire compris entre min (inclus) et max (inclus)
		random = (min + Math.floor(Math.random() * max));

		return random;
	}

	// Au moment où l'utilisateur envoie le formulaire...
	$('form').submit(function(event) {

	});
});