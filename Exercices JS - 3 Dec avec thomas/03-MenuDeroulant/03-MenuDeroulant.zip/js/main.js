$(document).ready(function() {

}); 